<?php

$meta['debug'] = [
    'onoff',
    '_caution' => 'security',
];
$meta['flavor'] = [
    'multichoice',
    '_choices' => [
        'traditional',
        'github-flavored',
        'markdown-extra',
    ],
];
