<?php

$conf['debug'] = 0;
$conf['flavor'] = 'github-flavored';
$conf['markdown_default'] = 0;
