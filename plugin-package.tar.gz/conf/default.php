<?php

$conf['debug'] = 0;
$conf['flavor'] = 'github-flavored';
