<?php

$lang['debug'] = '追加のデバッグ情報を表示する';
$lang['flavor'] = 'Markdown記法';
$lang['markdown_default'] = 'Markdown を DokuWiki のデフォルト構文にする (実験的機能)';
