<?php

$lang['debug'] = 'Display additional debug information';
$lang['flavor'] = 'Markdown flavor';
