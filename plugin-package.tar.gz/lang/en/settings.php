<?php

$lang['debug'] = 'Display additional debug information';
$lang['flavor'] = 'Markdown flavor';
$lang['markdown_default'] = 'Make Markdown to default DokuWiki syntax (experimental)';
